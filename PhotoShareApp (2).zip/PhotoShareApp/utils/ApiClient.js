import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import * as FileSystem from 'expo-file-system';
import Constants from 'expo-constants';

class ApiClient {
  constructor() {
    // Get the backend URL - in Replit, the backend runs on port 3001
    const domain = Constants.expoConfig?.extra?.domain || Constants.manifest?.extra?.domain;
    
    if (domain && domain !== 'localhost:5000') {
      // For Replit deployment, use HTTPS with the domain but backend port 3001
      // Remove any existing port and add 3001
      const cleanDomain = domain.replace(/:\d+$/, '');
      this.baseURL = `https://${cleanDomain}:3001`;
    } else {
      // For local development
      this.baseURL = 'http://localhost:3001';
    }
    
    console.log('ApiClient baseURL:', this.baseURL);
    console.log('Detected domain:', domain);
    
    this.client = axios.create({
      baseURL: this.baseURL,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
      withCredentials: true, // Important for session cookies
    });

    // Add request interceptor for authentication
    this.client.interceptors.request.use(
      async (config) => {
        try {
          // Get stored auth token if available
          const token = await SecureStore.getItemAsync('auth_token');
          if (token) {
            config.headers.Authorization = `Bearer ${token}`;
          }
        } catch (error) {
          console.warn('Failed to get auth token:', error);
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // Add response interceptor for error handling
    this.client.interceptors.response.use(
      (response) => response,
      async (error) => {
        if (error.response?.status === 401) {
          // Clear stored auth data on unauthorized
          try {
            await SecureStore.deleteItemAsync('auth_token');
            await SecureStore.deleteItemAsync('user_data');
          } catch (clearError) {
            console.warn('Failed to clear auth data:', clearError);
          }
        }
        return Promise.reject(error);
      }
    );
  }

  // Auth endpoints
  async getCurrentUser() {
    try {
      const response = await this.client.get('/api/auth/user');
      return response.data;
    } catch (error) {
      console.error('Failed to get current user:', error);
      throw this.handleError(error);
    }
  }

  // Development authentication methods
  async devLogin(username, email) {
    try {
      const response = await this.client.post('/api/auth/dev-login', {
        username,
        email
      });
      return response.data; // { token, user }
    } catch (error) {
      console.error('Dev login failed:', error);
      throw this.handleError(error);
    }
  }

  async mockLogin() {
    try {
      const response = await this.client.post('/api/auth/mock-login');
      return response.data; // { token, user }
    } catch (error) {
      console.error('Mock login failed:', error);
      throw this.handleError(error);
    }
  }

  // Photo endpoints
  async getMyPhotos() {
    try {
      const response = await this.client.get('/api/photos/mine');
      return response.data;
    } catch (error) {
      console.error('Failed to get my photos:', error);
      throw this.handleError(error);
    }
  }

  async getPublicPhotos(limit = 50) {
    try {
      const response = await this.client.get('/api/photos/public', {
        params: { limit }
      });
      return response.data;
    } catch (error) {
      console.error('Failed to get public photos:', error);
      throw this.handleError(error);
    }
  }

  async getPhoto(photoId) {
    try {
      const response = await this.client.get(`/api/photos/${photoId}`);
      return response.data;
    } catch (error) {
      console.error('Failed to get photo:', error);
      throw this.handleError(error);
    }
  }

  async createPhoto(photoData) {
    try {
      console.log('ApiClient: Creating photo record with data:', {
        objectPath: photoData.objectPath,
        title: photoData.title,
        isPublic: photoData.isPublic,
        mimeType: photoData.mimeType,
        fileSize: photoData.fileSize
      });
      const response = await this.client.post('/api/photos', photoData);
      console.log('ApiClient: Photo created successfully:', {
        id: response.data.id,
        objectPath: response.data.objectPath,
        title: response.data.title
      });
      return response.data;
    } catch (error) {
      console.error('ApiClient: Failed to create photo:', error);
      console.error('ApiClient: Photo creation error details:', {
        status: error.response?.status,
        statusText: error.response?.statusText,
        data: error.response?.data
      });
      throw this.handleError(error);
    }
  }

  async updatePhoto(photoId, updates) {
    try {
      const response = await this.client.put(`/api/photos/${photoId}`, updates);
      return response.data;
    } catch (error) {
      console.error('Failed to update photo:', error);
      throw this.handleError(error);
    }
  }

  async deletePhoto(photoId) {
    try {
      const response = await this.client.delete(`/api/photos/${photoId}`);
      return response.data;
    } catch (error) {
      console.error('Failed to delete photo:', error);
      throw this.handleError(error);
    }
  }

  // Object storage endpoints
  async getUploadUrl() {
    try {
      console.log('ApiClient: Requesting upload URL from backend...');
      const response = await this.client.post('/api/objects/upload');
      console.log('ApiClient: Upload URL response received:', {
        objectId: response.data.objectId,
        objectPath: response.data.objectPath,
        hasUploadURL: !!response.data.uploadURL
      });
      return response.data; // Returns { uploadURL, objectPath, objectId }
    } catch (error) {
      console.error('ApiClient: Failed to get upload URL:', error);
      throw this.handleError(error);
    }
  }

  async uploadFile(uploadUrl, file, progressCallback) {
    try {
      console.log('ApiClient: Starting upload to signed URL');
      console.log('ApiClient: Upload URL (first 50 chars):', uploadUrl.substring(0, 50) + '...');
      console.log('ApiClient: File details:', { 
        uri: file.uri, 
        type: file.type, 
        name: file.name,
        hasUri: !!file.uri
      });

      // Use FileSystem.uploadAsync with PUT method for Google Cloud Storage signed URLs
      const uploadOptions = {
        httpMethod: 'PUT',
        uploadType: FileSystem.UploadType.BINARY_CONTENT,
        headers: {
          'Content-Type': file.type || 'image/jpeg',
        },
      };

      console.log('ApiClient: Upload options configured:', {
        httpMethod: uploadOptions.httpMethod,
        uploadType: uploadOptions.uploadType,
        contentType: uploadOptions.headers['Content-Type']
      });

      // Set up progress callback if provided
      if (progressCallback) {
        uploadOptions.uploadProgressCallback = (progress) => {
          const percentCompleted = Math.round((progress.totalBytesSent / progress.totalBytesExpectedToSend) * 100);
          console.log(`ApiClient: Upload progress: ${percentCompleted}% (${progress.totalBytesSent}/${progress.totalBytesExpectedToSend} bytes)`);
          progressCallback(percentCompleted);
        };
      }

      console.log('ApiClient: Starting FileSystem.uploadAsync...');
      const response = await FileSystem.uploadAsync(uploadUrl, file.uri, uploadOptions);
      
      console.log('ApiClient: Upload response received:', {
        status: response.status,
        bodyLength: response.body ? response.body.length : 0,
        hasBody: !!response.body
      });

      // Check if upload was successful
      if (response.status < 200 || response.status >= 300) {
        console.error('ApiClient: Upload failed with status:', response.status);
        console.error('ApiClient: Upload error response body:', response.body);
        throw new Error(`Upload failed with status ${response.status}: ${response.body}`);
      }

      // Parse response body if it exists, otherwise return success indicator
      let responseData = {};
      if (response.body) {
        try {
          responseData = JSON.parse(response.body);
          console.log('ApiClient: Parsed response body:', responseData);
        } catch (parseError) {
          console.log('ApiClient: Response body is not JSON, assuming successful upload');
          responseData = { success: true };
        }
      } else {
        responseData = { success: true };
        console.log('ApiClient: No response body, upload appears successful');
      }

      console.log('ApiClient: Upload completed successfully');
      return responseData;
    } catch (error) {
      console.error('Failed to upload file:', error);
      console.error('Error details:', {
        message: error.message,
        code: error.code,
        response: error.response
      });
      throw this.handleError(error);
    }
  }

  // Get object URL for viewing
  getObjectUrl(objectPath) {
    if (!objectPath) return null;
    return `${this.baseURL}${objectPath}`;
  }

  // Utility methods
  handleError(error) {
    if (error.response) {
      // Server responded with error status
      const message = error.response.data?.message || error.response.data?.error || 'Server error occurred';
      return new Error(message);
    } else if (error.request) {
      // Request was made but no response received
      return new Error('Network error - please check your internet connection');
    } else {
      // Something else happened
      return new Error(error.message || 'An unexpected error occurred');
    }
  }

  async isConnected() {
    try {
      const response = await this.client.get('/health', { timeout: 5000 });
      return response.status === 200;
    } catch (error) {
      return false;
    }
  }

  // Store auth data
  async storeAuthToken(token) {
    try {
      await SecureStore.setItemAsync('auth_token', token);
    } catch (error) {
      console.error('Failed to store auth token:', error);
      throw error;
    }
  }

  async getAuthToken() {
    try {
      return await SecureStore.getItemAsync('auth_token');
    } catch (error) {
      console.error('Failed to get auth token:', error);
      return null;
    }
  }

  async clearAuthData() {
    try {
      await SecureStore.deleteItemAsync('auth_token');
      await SecureStore.deleteItemAsync('user_data');
    } catch (error) {
      console.error('Failed to clear auth data:', error);
    }
  }
}

// Create and export singleton instance
const apiClient = new ApiClient();
export default apiClient;