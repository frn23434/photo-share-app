import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, TextInput, ScrollView, ActivityIndicator } from 'react-native';
import { useAuth } from '../contexts/AuthContext';
import PhotoStorageService from '../utils/PhotoStorageService';

export default function ProfileScreen({ navigation }) {
  const { user, isAuthenticated, isLoading, isOnline, login, logout, mockLogin } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(user?.username || '');
  const [editEmail, setEditEmail] = useState(user?.email || '');
  const [uploadStatus, setUploadStatus] = useState(null);
  const [isRetrying, setIsRetrying] = useState(false);
  
  useEffect(() => {
    if (user) {
      setEditName(user.username || user.name || '');
      setEditEmail(user.email || '');
    }
    loadUploadStatus();
  }, [user]);
  
  const loadUploadStatus = async () => {
    try {
      const status = await PhotoStorageService.getUploadStatus();
      setUploadStatus(status);
    } catch (error) {
      console.error('Failed to load upload status:', error);
    }
  };

  const handleLogin = async () => {
    try {
      // For development, we'll use mock login
      // In production, this would use the OAuth flow
      Alert.alert(
        'Login Options',
        'Choose your login method:',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Demo Login', 
            onPress: async () => {
              try {
                await mockLogin();
                Alert.alert('Success', 'Logged in successfully!');
                await loadUploadStatus();
              } catch (error) {
                Alert.alert('Error', 'Login failed: ' + error.message);
              }
            }
          },
          // { 
          //   text: 'Replit OAuth', 
          //   onPress: async () => {
          //     try {
          //       await login();
          //       Alert.alert('Success', 'Logged in successfully!');
          //     } catch (error) {
          //       Alert.alert('Error', 'Login failed: ' + error.message);
          //     }
          //   }
          // }
        ]
      );
    } catch (error) {
      console.error('Login error:', error);
      Alert.alert('Error', 'Login failed');
    }
  };

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Logout', 
          onPress: async () => {
            try {
              await logout();
              Alert.alert('Logged out', 'You have been logged out successfully');
              setUploadStatus(null);
            } catch (error) {
              console.error('Logout error:', error);
              Alert.alert('Error', 'Logout failed, but you have been signed out locally.');
            }
          }
        }
      ]
    );
  };

  const saveProfile = () => {
    // Note: In a real app, you'd update the profile via API
    // For now, just show success message
    setIsEditing(false);
    Alert.alert('Profile Updated', 'Profile changes saved locally. Full profile editing will be available after backend integration.');
  };

  const cancelEdit = () => {
    setEditName(user?.username || user?.name || '');
    setEditEmail(user?.email || '');
    setIsEditing(false);
  };
  
  const retryFailedUploads = async () => {
    if (!isOnline) {
      Alert.alert('Offline', 'Please check your internet connection and try again.');
      return;
    }
    
    setIsRetrying(true);
    try {
      const results = await PhotoStorageService.retryFailedUploads();
      const successCount = results.filter(r => r.success).length;
      const failedCount = results.filter(r => !r.success).length;
      
      let message = `Retry completed: ${successCount} photos uploaded successfully`;
      if (failedCount > 0) {
        message += `, ${failedCount} still failed`;
      }
      
      Alert.alert('Retry Results', message);
      await loadUploadStatus();
    } catch (error) {
      console.error('Retry failed:', error);
      Alert.alert('Error', 'Failed to retry uploads: ' + error.message);
    } finally {
      setIsRetrying(false);
    }
  };
  
  const syncWithCloud = async () => {
    if (!isAuthenticated) {
      Alert.alert('Not Authenticated', 'Please log in to sync with cloud.');
      return;
    }
    
    if (!isOnline) {
      Alert.alert('Offline', 'Please check your internet connection and try again.');
      return;
    }
    
    try {
      await PhotoStorageService.syncWithBackend();
      await loadUploadStatus();
      Alert.alert('Success', 'Successfully synced with cloud!');
    } catch (error) {
      console.error('Sync failed:', error);
      Alert.alert('Error', 'Sync failed: ' + error.message);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.avatarContainer}>
          <Text style={styles.avatar}>👤</Text>
        </View>
        <Text style={styles.headerText}>Profile</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Account Information</Text>
        
        {isEditing ? (
          <View style={styles.editContainer}>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Name:</Text>
              <TextInput
                style={styles.input}
                value={editName}
                onChangeText={setEditName}
                placeholder="Enter your name"
              />
            </View>
            
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Email:</Text>
              <TextInput
                style={styles.input}
                value={editEmail}
                onChangeText={setEditEmail}
                placeholder="Enter your email"
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>
            
            <View style={styles.buttonRow}>
              <TouchableOpacity style={styles.saveButton} onPress={saveProfile}>
                <Text style={styles.saveButtonText}>Save</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.cancelButton} onPress={cancelEdit}>
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <View style={styles.infoContainer}>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Name:</Text>
              <Text style={styles.infoValue}>{user?.username || user?.name || 'Not logged in'}</Text>
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Email:</Text>
              <Text style={styles.infoValue}>{user?.email || 'Not logged in'}</Text>
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Status:</Text>
              <Text style={[styles.infoValue, isAuthenticated ? styles.online : styles.offline]}>
                {isAuthenticated ? (isOnline ? 'Online' : 'Offline') : 'Not logged in'}
              </Text>
            </View>
            
            {uploadStatus && (
              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>Photos:</Text>
                <Text style={styles.infoValue}>
                  {uploadStatus.uploaded}/{uploadStatus.total} synced
                  {uploadStatus.failed > 0 && ` • ${uploadStatus.failed} failed`}
                </Text>
              </View>
            )}
            
            <TouchableOpacity style={styles.editButton} onPress={() => setIsEditing(true)}>
              <Text style={styles.editButtonText}>Edit Profile</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>App Settings</Text>
        
        <TouchableOpacity style={styles.settingItem}>
          <Text style={styles.settingText}>Photo Quality</Text>
          <Text style={styles.settingValue}>High</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.settingItem}>
          <Text style={styles.settingText}>Auto Upload</Text>
          <Text style={styles.settingValue}>Enabled</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.settingItem}>
          <Text style={styles.settingText}>Storage Used</Text>
          <Text style={styles.settingValue}>2.3 GB</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Actions</Text>
        
        {isLoading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="small" color="#ff6b6b" />
            <Text style={styles.loadingText}>Loading...</Text>
          </View>
        ) : isAuthenticated ? (
          <>
            <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
              <Text style={styles.logoutButtonText}>Logout</Text>
            </TouchableOpacity>
            
            {uploadStatus?.failed > 0 && (
              <TouchableOpacity 
                style={[styles.actionButton, styles.retryButton]} 
                onPress={retryFailedUploads}
                disabled={isRetrying}
              >
                {isRetrying ? (
                  <ActivityIndicator size="small" color="white" />
                ) : (
                  <Text style={styles.actionButtonText}>Retry Failed Uploads ({uploadStatus.failed})</Text>
                )}
              </TouchableOpacity>
            )}
            
            <TouchableOpacity style={styles.actionButton} onPress={syncWithCloud}>
              <Text style={styles.actionButtonText}>Sync with Cloud</Text>
            </TouchableOpacity>
          </>
        ) : (
          <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
            <Text style={styles.loginButtonText}>Login</Text>
          </TouchableOpacity>
        )}
        
        <TouchableOpacity style={styles.actionButton}>
          <Text style={styles.actionButtonText}>Clear Cache</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.actionButton}>
          <Text style={styles.actionButtonText}>Help & Support</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#fff',
    padding: 30,
    paddingTop: 50,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  avatarContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#ff6b6b',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 15,
  },
  avatar: {
    fontSize: 40,
    color: 'white',
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  section: {
    backgroundColor: '#fff',
    marginTop: 20,
    marginHorizontal: 20,
    borderRadius: 15,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
  },
  infoContainer: {
    gap: 15,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 5,
  },
  infoLabel: {
    fontSize: 16,
    color: '#666',
    fontWeight: '500',
  },
  infoValue: {
    fontSize: 16,
    color: '#333',
  },
  online: {
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  offline: {
    color: '#FF5722',
    fontWeight: 'bold',
  },
  editContainer: {
    gap: 15,
  },
  inputGroup: {
    gap: 5,
  },
  label: {
    fontSize: 16,
    color: '#666',
    fontWeight: '500',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#f9f9f9',
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 10,
  },
  saveButton: {
    flex: 1,
    backgroundColor: '#4CAF50',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  saveButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#666',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  editButton: {
    backgroundColor: '#ff6b6b',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  editButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  settingText: {
    fontSize: 16,
    color: '#333',
  },
  settingValue: {
    fontSize: 16,
    color: '#666',
  },
  loginButton: {
    backgroundColor: '#4CAF50',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  loginButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  logoutButton: {
    backgroundColor: '#FF5722',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  logoutButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  actionButton: {
    backgroundColor: '#f0f0f0',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  actionButtonText: {
    color: '#333',
    fontSize: 16,
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 15,
    gap: 10,
  },
  loadingText: {
    fontSize: 16,
    color: '#666',
  },
  retryButton: {
    backgroundColor: '#FF5722',
  },
});