import * as SecureStore from 'expo-secure-store';
import * as WebBrowser from 'expo-web-browser';
import Constants from 'expo-constants';
import apiClient from './ApiClient';

class AuthService {
  constructor() {
    this.user = null;
    this.isAuthenticated = false;
    this.domain = Constants.expoConfig?.extra?.domain || Constants.manifest?.extra?.domain || 'localhost:5000';
    this.backendUrl = this.domain.includes('localhost') ? 
      'http://localhost:3001' : 
      `https://${this.domain.replace(':5000', ':3001')}`;
  }

  // Initialize auth state
  async initialize() {
    try {
      // Check if user has stored auth token
      const token = await SecureStore.getItemAsync('auth_token');
      if (token) {
        // Verify token is still valid by fetching user
        const user = await apiClient.getCurrentUser();
        this.user = user;
        this.isAuthenticated = true;
        return true;
      }
      return false;
    } catch (error) {
      console.error('Auth initialization failed:', error);
      // Clear invalid auth data
      await this.logout();
      return false;
    }
  }

  // Start OAuth login flow
  async login() {
    try {
      const authUrl = `${this.backendUrl}/auth/replit`;
      const redirectUrl = `${this.backendUrl}/auth/callback`;

      // Open browser for OAuth flow
      const result = await WebBrowser.openBrowserAsync(authUrl, {
        dismissButtonStyle: 'cancel',
        preferredBarTintColor: '#ff6b6b',
        preferredControlTintColor: 'white',
      });

      if (result.type === 'cancel') {
        throw new Error('User cancelled authentication');
      }

      // Note: In a production app, you would need to handle the OAuth callback
      // and extract the token. For now, we'll implement a simpler flow.
      throw new Error('OAuth flow needs to be completed - this is a placeholder');
      
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    }
  }

  // Development login using the new backend endpoints
  async devLogin(username, email) {
    try {
      // Call the backend dev-login endpoint
      const authData = await apiClient.devLogin(username, email);
      
      // Store the token
      await apiClient.storeAuthToken(authData.token);
      
      // Set user data
      this.user = authData.user;
      this.isAuthenticated = true;
      
      // Store user data locally
      await SecureStore.setItemAsync('user_data', JSON.stringify(authData.user));
      
      return authData.user;
    } catch (error) {
      console.error('Dev login failed:', error);
      throw error;
    }
  }

  // Mock login for testing
  async mockLogin() {
    try {
      // Call the backend mock-login endpoint
      const authData = await apiClient.mockLogin();
      
      // Store the token
      await apiClient.storeAuthToken(authData.token);
      
      // Set user data
      this.user = authData.user;
      this.isAuthenticated = true;
      
      // Store user data locally
      await SecureStore.setItemAsync('user_data', JSON.stringify(authData.user));
      
      return authData.user;
    } catch (error) {
      console.error('Mock login failed:', error);
      throw error;
    }
  }

  // Alternative login for development - using direct API call (kept for compatibility)
  async loginWithSession(sessionData) {
    try {
      if (sessionData.token) {
        await apiClient.storeAuthToken(sessionData.token);
      }
      
      const user = await apiClient.getCurrentUser();
      this.user = user;
      this.isAuthenticated = true;
      
      // Store user data
      await SecureStore.setItemAsync('user_data', JSON.stringify(user));
      
      return user;
    } catch (error) {
      console.error('Session login failed:', error);
      throw error;
    }
  }

  // Logout
  async logout() {
    try {
      // Clear stored auth data
      await apiClient.clearAuthData();
      this.user = null;
      this.isAuthenticated = false;
    } catch (error) {
      console.error('Logout failed:', error);
      // Still clear local state even if server logout fails
      this.user = null;
      this.isAuthenticated = false;
    }
  }

  // Get current user
  getCurrentUser() {
    return this.user;
  }

  // Check if authenticated
  getIsAuthenticated() {
    return this.isAuthenticated;
  }

  // Get stored user data (fallback when offline)
  async getStoredUser() {
    try {
      const userData = await SecureStore.getItemAsync('user_data');
      return userData ? JSON.parse(userData) : null;
    } catch (error) {
      console.error('Failed to get stored user data:', error);
      return null;
    }
  }

  // Check if we have any auth data (online or offline)
  async hasAuthData() {
    try {
      const token = await SecureStore.getItemAsync('auth_token');
      return !!token;
    } catch (error) {
      return false;
    }
  }

  // Refresh user data
  async refreshUser() {
    try {
      if (!this.isAuthenticated) {
        throw new Error('Not authenticated');
      }
      
      const user = await apiClient.getCurrentUser();
      this.user = user;
      await SecureStore.setItemAsync('user_data', JSON.stringify(user));
      return user;
    } catch (error) {
      console.error('Failed to refresh user:', error);
      throw error;
    }
  }
}

// Create and export singleton instance
const authService = new AuthService();
export default authService;