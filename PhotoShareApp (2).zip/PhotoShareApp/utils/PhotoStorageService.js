import AsyncStorage from '@react-native-async-storage/async-storage';
import * as MediaLibrary from 'expo-media-library';
import * as FileSystem from 'expo-file-system';
import apiClient from './ApiClient';

const PHOTOS_KEY = '@PhotoShareApp:photos';
const CLOUD_PHOTOS_KEY = '@PhotoShareApp:cloudPhotos';

export class PhotoStorageService {
  // Request media library permissions
  static async requestPermissions() {
    try {
      const { status } = await MediaLibrary.requestPermissionsAsync();
      return status === 'granted';
    } catch (error) {
      console.error('Error requesting media library permissions:', error);
      return false;
    }
  }

  // Save a photo to device storage and upload to cloud
  static async savePhoto(photoUri, options = {}) {
    try {
      // Check permissions first
      const hasPermission = await this.requestPermissions();
      if (!hasPermission) {
        throw new Error('Media library permission denied');
      }

      // Save to media library first
      const asset = await MediaLibrary.saveToLibraryAsync(photoUri);
      
      // Get displayable URI for cross-platform compatibility
      let displayUri = asset.uri;
      try {
        const assetInfo = await MediaLibrary.getAssetInfoAsync(asset.id);
        if (assetInfo && assetInfo.localUri) {
          displayUri = assetInfo.localUri;
        }
      } catch (uriError) {
        console.warn('Could not get displayable URI, using original:', uriError);
      }
      
      // Create local photo metadata
      const localPhotoMetadata = {
        id: asset.id,
        uri: displayUri,
        originalUri: asset.uri,
        filename: asset.filename,
        timestamp: Date.now(),
        width: asset.width,
        height: asset.height,
        location: options.location || null,
        tags: options.tags || [],
        isLocal: true,
        cloudId: null,
        uploadStatus: 'pending', // pending, uploading, uploaded, failed
      };

      // Save local metadata first
      await this.addPhotoMetadata(localPhotoMetadata);

      // Try to upload to cloud storage
      try {
        const cloudPhoto = await this.uploadToCloud(photoUri, localPhotoMetadata, options);
        
        // Update local metadata with cloud info
        localPhotoMetadata.cloudId = cloudPhoto.id;
        localPhotoMetadata.uploadStatus = 'uploaded';
        localPhotoMetadata.cloudUrl = cloudPhoto.objectPath;
        await this.updatePhotoMetadata(localPhotoMetadata.id, localPhotoMetadata);
        
        return { ...localPhotoMetadata, cloudPhoto };
      } catch (uploadError) {
        console.warn('Failed to upload to cloud, saved locally only:', uploadError);
        // Update status to failed but keep the photo
        localPhotoMetadata.uploadStatus = 'failed';
        await this.updatePhotoMetadata(localPhotoMetadata.id, localPhotoMetadata);
        
        return localPhotoMetadata;
      }
    } catch (error) {
      console.error('Error saving photo:', error);
      throw error;
    }
  }

  // Upload photo to cloud storage
  static async uploadToCloud(photoUri, metadata, options = {}) {
    try {
      // Get file info
      const fileInfo = await FileSystem.getInfoAsync(photoUri);
      if (!fileInfo.exists) {
        throw new Error('Photo file not found');
      }

      // Get upload URL and object path from backend
      console.log('PhotoStorageService: Requesting upload URL from backend...');
      const uploadData = await apiClient.getUploadUrl();
      console.log('PhotoStorageService: Upload data received:', {
        objectId: uploadData.objectId,
        objectPath: uploadData.objectPath,
        hasUploadURL: !!uploadData.uploadURL
      });
      
      // Determine correct MIME type from file extension
      let mimeType = 'image/jpeg'; // Default
      if (metadata.filename) {
        const extension = metadata.filename.toLowerCase().split('.').pop();
        if (extension === 'png') mimeType = 'image/png';
        else if (extension === 'jpg' || extension === 'jpeg') mimeType = 'image/jpeg';
        else if (extension === 'gif') mimeType = 'image/gif';
        else if (extension === 'webp') mimeType = 'image/webp';
      }
      
      // Prepare file for upload
      const fileData = {
        uri: photoUri,
        type: mimeType,
        name: metadata.filename || `photo_${Date.now()}.jpg`,
      };

      // Upload file to cloud storage
      console.log('PhotoStorageService: Starting file upload with data:', {
        fileName: fileData.name,
        mimeType: fileData.type,
        fileSize: fileInfo.size
      });
      const uploadResult = await apiClient.uploadFile(uploadData.uploadURL, fileData, (progress) => {
        console.log(`PhotoStorageService: Upload progress: ${progress}%`);
      });

      console.log('PhotoStorageService: Upload completed successfully, creating photo record...');

      // Only create photo record if upload was successful
      // The uploadFile method now throws an error if status is not 200-299
      const photoData = {
        objectPath: uploadData.objectPath, // Use the exact objectPath from upload URL generation
        title: options.title || `Photo ${new Date().toLocaleDateString()}`,
        description: options.description || '',
        tags: metadata.tags || [],
        isPublic: options.isPublic || false,
        fileSize: fileInfo.size,
        mimeType: mimeType,
        width: metadata.width,
        height: metadata.height,
      };

      console.log('PhotoStorageService: Creating photo record with data:', {
        objectPath: photoData.objectPath,
        title: photoData.title,
        isPublic: photoData.isPublic,
        mimeType: photoData.mimeType,
        fileSize: photoData.fileSize
      });

      const cloudPhoto = await apiClient.createPhoto(photoData);
      console.log('PhotoStorageService: Photo record created successfully:', {
        id: cloudPhoto.id,
        objectPath: cloudPhoto.objectPath
      });
      
      // Store cloud photo metadata locally
      await this.addCloudPhotoMetadata(cloudPhoto);
      
      return cloudPhoto;
    } catch (error) {
      console.error('Cloud upload failed:', error);
      throw error;
    }
  }

  // Get all photos (local and cloud)
  static async getPhotos() {
    try {
      // Get local photos
      const localPhotosJson = await AsyncStorage.getItem(PHOTOS_KEY);
      const localPhotos = localPhotosJson ? JSON.parse(localPhotosJson) : [];

      // Get cloud photos metadata
      const cloudPhotosJson = await AsyncStorage.getItem(CLOUD_PHOTOS_KEY);
      const cloudPhotos = cloudPhotosJson ? JSON.parse(cloudPhotosJson) : [];

      // Try to fetch latest cloud photos if online
      try {
        const isOnline = await apiClient.isConnected();
        if (isOnline) {
          const latestCloudPhotos = await apiClient.getMyPhotos();
          await this.saveCloudPhotosMetadata(latestCloudPhotos);
          
          // Combine and deduplicate photos
          return this.mergeLocalAndCloudPhotos(localPhotos, latestCloudPhotos);
        }
      } catch (error) {
        console.warn('Failed to fetch latest cloud photos, using cached:', error);
      }

      // Fallback to cached data when offline
      return this.mergeLocalAndCloudPhotos(localPhotos, cloudPhotos);
    } catch (error) {
      console.error('Error loading photos:', error);
      return [];
    }
  }

  // Merge local and cloud photos, avoiding duplicates
  static mergeLocalAndCloudPhotos(localPhotos, cloudPhotos) {
    const merged = [...localPhotos];
    
    cloudPhotos.forEach(cloudPhoto => {
      // Check if this cloud photo already exists in local photos
      const existingLocal = localPhotos.find(local => local.cloudId === cloudPhoto.id);
      
      if (!existingLocal) {
        // Add cloud photo with display metadata
        merged.push({
          id: `cloud_${cloudPhoto.id}`,
          cloudId: cloudPhoto.id,
          uri: apiClient.getObjectUrl(cloudPhoto.objectPath),
          filename: cloudPhoto.title,
          timestamp: new Date(cloudPhoto.createdAt).getTime(),
          width: cloudPhoto.width,
          height: cloudPhoto.height,
          tags: cloudPhoto.tags || [],
          isLocal: false,
          uploadStatus: 'uploaded',
          cloudUrl: cloudPhoto.objectPath,
          isPublic: cloudPhoto.isPublic,
        });
      }
    });

    // Sort by timestamp (newest first)
    return merged.sort((a, b) => b.timestamp - a.timestamp);
  }

  // Add photo metadata to AsyncStorage
  static async addPhotoMetadata(photoMetadata) {
    try {
      const photosJson = await AsyncStorage.getItem(PHOTOS_KEY);
      const existingPhotos = photosJson ? JSON.parse(photosJson) : [];
      const updatedPhotos = [photoMetadata, ...existingPhotos];
      await AsyncStorage.setItem(PHOTOS_KEY, JSON.stringify(updatedPhotos));
    } catch (error) {
      console.error('Error adding photo metadata:', error);
      throw error;
    }
  }

  // Update existing photo metadata
  static async updatePhotoMetadata(photoId, updates) {
    try {
      const photosJson = await AsyncStorage.getItem(PHOTOS_KEY);
      const existingPhotos = photosJson ? JSON.parse(photosJson) : [];
      const photoIndex = existingPhotos.findIndex(photo => photo.id === photoId);
      
      if (photoIndex !== -1) {
        existingPhotos[photoIndex] = { ...existingPhotos[photoIndex], ...updates };
        await AsyncStorage.setItem(PHOTOS_KEY, JSON.stringify(existingPhotos));
      }
    } catch (error) {
      console.error('Error updating photo metadata:', error);
      throw error;
    }
  }

  // Add cloud photo metadata
  static async addCloudPhotoMetadata(cloudPhoto) {
    try {
      const cloudPhotosJson = await AsyncStorage.getItem(CLOUD_PHOTOS_KEY);
      const existingCloudPhotos = cloudPhotosJson ? JSON.parse(cloudPhotosJson) : [];
      
      // Check if already exists
      const existingIndex = existingCloudPhotos.findIndex(p => p.id === cloudPhoto.id);
      if (existingIndex !== -1) {
        existingCloudPhotos[existingIndex] = cloudPhoto;
      } else {
        existingCloudPhotos.unshift(cloudPhoto);
      }
      
      await AsyncStorage.setItem(CLOUD_PHOTOS_KEY, JSON.stringify(existingCloudPhotos));
    } catch (error) {
      console.error('Error adding cloud photo metadata:', error);
      throw error;
    }
  }

  // Save multiple cloud photos metadata
  static async saveCloudPhotosMetadata(cloudPhotos) {
    try {
      await AsyncStorage.setItem(CLOUD_PHOTOS_KEY, JSON.stringify(cloudPhotos));
    } catch (error) {
      console.error('Error saving cloud photos metadata:', error);
      throw error;
    }
  }

  // Remove a photo (local and/or cloud)
  static async removePhoto(photoId) {
    try {
      // Get current photos to determine if it's local or cloud
      const localPhotosJson = await AsyncStorage.getItem(PHOTOS_KEY);
      const localPhotos = localPhotosJson ? JSON.parse(localPhotosJson) : [];
      const photo = localPhotos.find(p => p.id === photoId);

      if (photo) {
        // Remove from local storage
        const updatedLocalPhotos = localPhotos.filter(p => p.id !== photoId);
        await AsyncStorage.setItem(PHOTOS_KEY, JSON.stringify(updatedLocalPhotos));

        // If photo was uploaded to cloud, delete from backend too
        if (photo.cloudId) {
          try {
            await apiClient.deletePhoto(photo.cloudId);
          } catch (cloudError) {
            console.warn('Failed to delete from cloud storage:', cloudError);
          }
        }
        return true;
      }

      // Check if it's a cloud-only photo
      if (photoId.startsWith('cloud_')) {
        const cloudId = photoId.replace('cloud_', '');
        try {
          await apiClient.deletePhoto(cloudId);
          
          // Remove from cached cloud photos
          const cloudPhotosJson = await AsyncStorage.getItem(CLOUD_PHOTOS_KEY);
          const cloudPhotos = cloudPhotosJson ? JSON.parse(cloudPhotosJson) : [];
          const updatedCloudPhotos = cloudPhotos.filter(p => p.id !== cloudId);
          await AsyncStorage.setItem(CLOUD_PHOTOS_KEY, JSON.stringify(updatedCloudPhotos));
          
          return true;
        } catch (error) {
          console.error('Failed to delete cloud photo:', error);
          return false;
        }
      }

      return false;
    } catch (error) {
      console.error('Error removing photo:', error);
      return false;
    }
  }

  // Clear all photo metadata (for debugging/reset purposes)
  static async clearAllPhotos() {
    try {
      await AsyncStorage.removeItem(PHOTOS_KEY);
      return true;
    } catch (error) {
      console.error('Error clearing photos:', error);
      return false;
    }
  }

  // Get photo count
  static async getPhotoCount() {
    try {
      const photos = await this.getPhotos();
      return photos.length;
    } catch (error) {
      console.error('Error getting photo count:', error);
      return 0;
    }
  }

  // Retry failed uploads
  static async retryFailedUploads() {
    try {
      const localPhotosJson = await AsyncStorage.getItem(PHOTOS_KEY);
      const localPhotos = localPhotosJson ? JSON.parse(localPhotosJson) : [];
      const failedPhotos = localPhotos.filter(photo => photo.uploadStatus === 'failed');
      
      const results = [];
      for (const photo of failedPhotos) {
        try {
          // Update status to uploading
          photo.uploadStatus = 'uploading';
          await this.updatePhotoMetadata(photo.id, photo);
          
          // Retry upload
          const cloudPhoto = await this.uploadToCloud(photo.uri, photo, {});
          
          // Update with success
          photo.cloudId = cloudPhoto.id;
          photo.uploadStatus = 'uploaded';
          photo.cloudUrl = cloudPhoto.objectPath;
          await this.updatePhotoMetadata(photo.id, photo);
          
          results.push({ photoId: photo.id, success: true });
        } catch (error) {
          // Update back to failed
          photo.uploadStatus = 'failed';
          await this.updatePhotoMetadata(photo.id, photo);
          
          results.push({ photoId: photo.id, success: false, error: error.message });
        }
      }
      
      return results;
    } catch (error) {
      console.error('Error retrying failed uploads:', error);
      return [];
    }
  }

  // Get upload status summary
  static async getUploadStatus() {
    try {
      const localPhotosJson = await AsyncStorage.getItem(PHOTOS_KEY);
      const localPhotos = localPhotosJson ? JSON.parse(localPhotosJson) : [];
      
      const status = {
        total: localPhotos.length,
        uploaded: localPhotos.filter(p => p.uploadStatus === 'uploaded').length,
        pending: localPhotos.filter(p => p.uploadStatus === 'pending').length,
        uploading: localPhotos.filter(p => p.uploadStatus === 'uploading').length,
        failed: localPhotos.filter(p => p.uploadStatus === 'failed').length,
      };
      
      return status;
    } catch (error) {
      console.error('Error getting upload status:', error);
      return { total: 0, uploaded: 0, pending: 0, uploading: 0, failed: 0 };
    }
  }

  // Sync photos with backend
  static async syncWithBackend() {
    try {
      const isOnline = await apiClient.isConnected();
      if (!isOnline) {
        throw new Error('Device is offline');
      }
      
      // Get latest cloud photos
      const cloudPhotos = await apiClient.getMyPhotos();
      await this.saveCloudPhotosMetadata(cloudPhotos);
      
      // Retry any failed uploads
      const retryResults = await this.retryFailedUploads();
      
      return {
        cloudPhotosCount: cloudPhotos.length,
        retryResults,
        lastSyncTime: Date.now(),
      };
    } catch (error) {
      console.error('Error syncing with backend:', error);
      throw error;
    }
  }

  // Validate if a photo file still exists
  static async validatePhotoExists(photoUri) {
    try {
      // Handle different URI schemes (file://, ph://, content://)
      if (photoUri.startsWith('ph://') || photoUri.startsWith('content://')) {
        // For ph:// (iOS) and content:// (Android) URIs, we can't use FileSystem
        // Instead, we'll assume they exist if we have the URI
        // MediaLibrary manages these assets, so they should be valid
        return true;
      }
      
      // For file:// URIs, use FileSystem to check existence
      const fileInfo = await FileSystem.getInfoAsync(photoUri);
      return fileInfo.exists;
    } catch (error) {
      console.error('Error validating photo existence:', error);
      return false;
    }
  }

  // Clean up metadata for photos that no longer exist
  static async cleanupOrphanedPhotos() {
    try {
      const photos = await this.getPhotos();
      const validPhotos = [];

      for (const photo of photos) {
        // For MediaLibrary assets, we'll try to verify through MediaLibrary
        let exists = false;
        
        try {
          if (photo.id) {
            // Try to get asset info by ID first (most reliable)
            const assetInfo = await MediaLibrary.getAssetInfoAsync(photo.id);
            exists = !!assetInfo;
          } else {
            // Fallback to URI validation
            exists = await this.validatePhotoExists(photo.uri);
          }
        } catch (assetError) {
          // If MediaLibrary fails, try URI validation
          exists = await this.validatePhotoExists(photo.uri);
        }
        
        if (exists) {
          validPhotos.push(photo);
        }
      }

      if (validPhotos.length !== photos.length) {
        await AsyncStorage.setItem(PHOTOS_KEY, JSON.stringify(validPhotos));
        console.log(`Cleaned up ${photos.length - validPhotos.length} orphaned photos`);
      }

      return validPhotos;
    } catch (error) {
      console.error('Error cleaning up orphaned photos:', error);
      return await this.getPhotos(); // Return existing photos if cleanup fails
    }
  }
}

export default PhotoStorageService;