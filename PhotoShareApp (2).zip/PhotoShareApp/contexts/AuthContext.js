import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import authService from '../utils/AuthService';
import apiClient from '../utils/ApiClient';

const AuthContext = createContext({});

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const initializationRef = useRef(false);

  // Initialize auth state on app start
  useEffect(() => {
    // Temporarily disabled to fix loading issues
    // Will re-enable after testing basic app functionality
    console.log('Auth initialization skipped for testing');
  }, []);

  const login = async (sessionData = null) => {
    try {
      setIsLoading(true);
      
      let userData;
      if (sessionData) {
        // Direct session login (for development/testing)
        userData = await authService.loginWithSession(sessionData);
      } else {
        // OAuth flow
        userData = await authService.login();
      }
      
      setUser(userData);
      setIsAuthenticated(true);
      return userData;
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Development login methods
  const devLogin = async (username, email) => {
    try {
      setIsLoading(true);
      const userData = await authService.devLogin(username, email);
      setUser(userData);
      setIsAuthenticated(true);
      return userData;
    } catch (error) {
      console.error('Dev login failed:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      setIsLoading(true);
      await authService.logout();
      setUser(null);
      setIsAuthenticated(false);
    } catch (error) {
      console.error('Logout failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const refreshUser = async () => {
    try {
      if (!isAuthenticated) return null;
      
      const online = await apiClient.isConnected();
      setIsOnline(online);
      
      if (online) {
        const userData = await authService.refreshUser();
        setUser(userData);
        return userData;
      }
      return user; // Return cached user when offline
    } catch (error) {
      console.error('Failed to refresh user:', error);
      // If refresh fails with auth error, logout
      if (error.message.includes('401') || error.message.includes('unauthorized')) {
        await logout();
      }
      throw error;
    }
  };

  // Development helper - mock login for testing
  const mockLogin = async () => {
    try {
      setIsLoading(true);
      const userData = await authService.mockLogin();
      setUser(userData);
      setIsAuthenticated(true);
      return userData;
    } catch (error) {
      console.error('Mock login failed:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const contextValue = {
    user,
    isAuthenticated,
    isLoading,
    isOnline,
    login,
    logout,
    refreshUser,
    devLogin, // Development login method
    mockLogin, // Remove this in production
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};