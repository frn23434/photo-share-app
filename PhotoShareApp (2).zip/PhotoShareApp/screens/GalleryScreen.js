import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image, Dimensions, Alert, ActivityIndicator, RefreshControl } from 'react-native';
import * as FileSystem from 'expo-file-system';
import PhotoStorageService from '../utils/PhotoStorageService';
import { useAuth } from '../contexts/AuthContext';
import { useFocusEffect } from '@react-navigation/native';

const { width } = Dimensions.get('window');
const imageSize = width / 3 - 10;

export default function GalleryScreen({ navigation }) {
  const [photos, setPhotos] = useState([]);
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [uploadStatus, setUploadStatus] = useState(null);
  const { isAuthenticated, isOnline } = useAuth();

  useEffect(() => {
    loadPhotos();
  }, []);

  useFocusEffect(
    React.useCallback(() => {
      // Refresh photos when screen comes into focus
      loadPhotos();
    }, [])
  );

  const loadPhotos = async (isRefresh = false) => {
    try {
      if (isRefresh) {
        setIsRefreshing(true);
      } else {
        setIsLoading(true);
      }
      
      // Load photos (includes both local and cloud photos)
      const savedPhotos = await PhotoStorageService.getPhotos();
      setPhotos(savedPhotos);
      
      // Get upload status summary
      const status = await PhotoStorageService.getUploadStatus();
      setUploadStatus(status);
      
      // Auto-sync with backend if authenticated and online
      if (isAuthenticated && isOnline && isRefresh) {
        try {
          await PhotoStorageService.syncWithBackend();
          // Reload photos after sync
          const updatedPhotos = await PhotoStorageService.getPhotos();
          setPhotos(updatedPhotos);
          const updatedStatus = await PhotoStorageService.getUploadStatus();
          setUploadStatus(updatedStatus);
        } catch (syncError) {
          console.warn('Sync failed:', syncError);
        }
      }
    } catch (error) {
      console.error('Error loading photos:', error);
      Alert.alert('Error', 'Failed to load photos');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  const renderPhoto = ({ item }) => (
    <TouchableOpacity
      style={styles.photoContainer}
      onPress={() => setSelectedPhoto(item)}
    >
      <Image source={{ uri: item.uri }} style={styles.photo} />
      {/* Upload status indicator */}
      {item.isLocal && (
        <View style={styles.statusIndicator}>
          {item.uploadStatus === 'uploaded' && (
            <View style={[styles.statusDot, styles.uploaded]} />
          )}
          {item.uploadStatus === 'failed' && (
            <View style={[styles.statusDot, styles.failed]} />
          )}
          {item.uploadStatus === 'pending' && (
            <View style={[styles.statusDot, styles.pending]} />
          )}
          {item.uploadStatus === 'uploading' && (
            <ActivityIndicator size="small" color="white" />
          )}
        </View>
      )}
      {/* Cloud photo indicator */}
      {!item.isLocal && (
        <View style={styles.cloudIndicator}>
          <Text style={styles.cloudIcon}>☁️</Text>
        </View>
      )}
    </TouchableOpacity>
  );

  const closeModal = () => {
    setSelectedPhoto(null);
  };

  const sharePhoto = () => {
    Alert.alert('Share Photo', 'Sharing functionality will be added soon!');
  };

  const deletePhoto = () => {
    Alert.alert(
      'Delete Photo',
      'Are you sure you want to delete this photo from the gallery?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive',
          onPress: async () => {
            try {
              await PhotoStorageService.removePhoto(selectedPhoto.id);
              setPhotos(photos.filter(photo => photo.id !== selectedPhoto.id));
              setSelectedPhoto(null);
              Alert.alert('Success', 'Photo removed from gallery');
            } catch (error) {
              console.error('Error deleting photo:', error);
              Alert.alert('Error', 'Failed to delete photo');
            }
          }
        }
      ]
    );
  };

  if (selectedPhoto) {
    return (
      <View style={styles.modalContainer}>
        <TouchableOpacity style={styles.closeButton} onPress={closeModal}>
          <Text style={styles.closeButtonText}>✕</Text>
        </TouchableOpacity>
        <Image source={{ uri: selectedPhoto.uri }} style={styles.fullSizeImage} />
        <View style={styles.actionButtons}>
          <TouchableOpacity style={styles.actionButton} onPress={sharePhoto}>
            <Text style={styles.actionButtonText}>Share</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionButton, styles.deleteButton]} onPress={deletePhoto}>
            <Text style={styles.actionButtonText}>Delete</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.headerText}>My Photos</Text>
            {uploadStatus && (
              <Text style={styles.statusText}>
                {uploadStatus.uploaded}/{uploadStatus.total} synced
                {uploadStatus.failed > 0 && ` • ${uploadStatus.failed} failed`}
                {!isOnline && ' • Offline'}
              </Text>
            )}
          </View>
          <TouchableOpacity 
            style={styles.cameraButton} 
            onPress={() => navigation.navigate('Camera')}
          >
            <Text style={styles.cameraButtonText}>📷</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#ff6b6b" />
          <Text style={styles.loadingText}>Loading photos...</Text>
        </View>
      ) : photos.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No photos yet</Text>
          <Text style={styles.emptySubtext}>Take your first photo!</Text>
          <TouchableOpacity 
            style={styles.takePhotoButton} 
            onPress={() => navigation.navigate('Camera')}
          >
            <Text style={styles.takePhotoButtonText}>Take Photo</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={photos}
          renderItem={renderPhoto}
          keyExtractor={(item) => item.id}
          numColumns={3}
          contentContainerStyle={styles.photoGrid}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={isRefreshing}
              onRefresh={() => loadPhotos(true)}
              colors={['#ff6b6b']}
              tintColor="#ff6b6b"
            />
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    padding: 20,
    paddingTop: 40,
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  cameraButton: {
    backgroundColor: '#ff6b6b',
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cameraButtonText: {
    fontSize: 20,
  },
  photoGrid: {
    padding: 5,
  },
  photoContainer: {
    margin: 5,
  },
  photo: {
    width: imageSize,
    height: imageSize,
    borderRadius: 10,
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#666',
    marginBottom: 10,
  },
  emptySubtext: {
    fontSize: 16,
    color: '#999',
    marginBottom: 30,
  },
  takePhotoButton: {
    backgroundColor: '#ff6b6b',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 25,
  },
  takePhotoButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButton: {
    position: 'absolute',
    top: 50,
    right: 20,
    zIndex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeButtonText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  fullSizeImage: {
    width: '90%',
    height: '70%',
    resizeMode: 'contain',
  },
  actionButtons: {
    flexDirection: 'row',
    position: 'absolute',
    bottom: 50,
    gap: 20,
  },
  actionButton: {
    backgroundColor: '#ff6b6b',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 25,
  },
  deleteButton: {
    backgroundColor: '#ff4757',
  },
  actionButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  loadingText: {
    fontSize: 16,
    color: '#666',
    marginTop: 10,
  },
  statusText: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  statusIndicator: {
    position: 'absolute',
    top: 5,
    right: 5,
    backgroundColor: 'rgba(0,0,0,0.7)',
    borderRadius: 10,
    padding: 3,
    minWidth: 16,
    minHeight: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  uploaded: {
    backgroundColor: '#4CAF50',
  },
  failed: {
    backgroundColor: '#FF5722',
  },
  pending: {
    backgroundColor: '#FFC107',
  },
  cloudIndicator: {
    position: 'absolute',
    top: 5,
    left: 5,
    backgroundColor: 'rgba(135,206,235,0.8)',
    borderRadius: 8,
    padding: 2,
  },
  cloudIcon: {
    fontSize: 12,
  },
});